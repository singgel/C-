﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace MainAppRelease
{
    static class Program
    {
        [DllImport("mainAppDll.dll")]
        public static extern void StartSendMessage(string strMsg);

        [DllImport("mainAppDll.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr ConvertResourceData(byte[] bySource, long in_length);

        [DllImport("mainAppDll.dll", EntryPoint = "GetResourceDataLength")]
        public static extern int GetResourceDataLength();

        [DllImport("mainAppDll.dll", EntryPoint = "ReleaseResource")]
        public static extern void ReleaseResource();


        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                StartSendMessage(args[0]);

                Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("MainAppRelease.MainApp.exe");
                byte[] bs = new byte[stream.Length];
                stream.Read(bs, 0, (int)stream.Length);
                //===================================================================
                long inlength = bs.Length;
                int lpByte = (int)ConvertResourceData(bs, inlength);
                long tarLen = 0;
                tarLen = (long)GetResourceDataLength();
                byte[] vbyte = new byte[tarLen];
                for (int i = 0; i < tarLen; i++)
                {
                    vbyte[i] = (byte)Marshal.PtrToStructure((IntPtr)(lpByte++), typeof(byte));
                }
                ReleaseResource();
                //====================================================================
                Assembly asm = Assembly.Load(vbyte);//解密后加载  

                MethodInfo info = asm.EntryPoint;
                ParameterInfo[] parameters = info.GetParameters();
                if ((parameters != null) && (parameters.Length > 0))
                {
                    info.Invoke(null, (object[])args);
                }
                else
                {
                    info.Invoke(null, null);

                }
            }
            else
            {
                System.Diagnostics.ProcessStartInfo p = null;
                System.Diagnostics.Process Proc;
                string strExePath = System.AppDomain.CurrentDomain.BaseDirectory;

                p = new ProcessStartInfo("RunApp.exe", "");
                p.WorkingDirectory = strExePath;//设置此外部程序所在windows目录
                //p.WindowStyle = ProcessWindowStyle.Hidden;//在调用外部exe程序的时候，控制台窗口不弹出                
                Proc = System.Diagnostics.Process.Start(p);//调用外部程序


            }


        }
    }

}
